# task_extractor.py - Extract Task IDs by assignee name and export to Excel
# Usage: python task_extractor.py

# ── CHANGE THIS PATH if you move the Excel file elsewhere ──
FILE_PATH = r"c:\Users\abhin\Downloads\Billing Test\abhinav-input-Jun'26dump.xlsx"
# ────────────────────────────────────────────────────────────

import os, sys
from datetime import datetime
from pathlib import Path

if sys.stdout.encoding != "utf-8":
    try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except: pass

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

SOURCE = Path(FILE_PATH)
BASE_DIR = SOURCE.parent

# Sheet layout: (header_row, data_start, task_id_col, name_col, extra_cols)
# extra_cols maps field names -> column indices for optional data
SHEETS = {
    "Jira Dump": {
        "hdr": 7, "start": 8, "task": 6, "name": 7,
        "cols": {"project":4, "app":5, "status":3, "points":2,
                 "delivered":8, "milestone":10, "billed_pct":11, "billed_pts":12}
    },
    "Digital": {
        "hdr": 5, "start": 6, "task": 5, "name": 6,
        "cols": {"project":4, "app":None, "status":3, "points":2,
                 "delivered":8, "milestone":None, "billed_pct":None, "billed_pts":None}
    },
}

FIELDS = ["task_id","project","app","status","points","delivered","milestone","billed_pct","billed_pts","sheet"]
HEADERS = ["Task ID","Project Name","Application","Status","Points","Delivered","Milestone","Billed %","Billed Pts","Source"]
COL_WIDTHS = [18, 55, 16, 15, 12, 16, 13, 11, 13, 15]

# Styles
_border = Border(*[Side("thin", "B4C6E7")]*4)
_hdr_font = Font("Calibri", bold=True, size=12, color="FFFFFF")
_hdr_fill = PatternFill("solid", fgColor="2F5496")
_alt_fill = PatternFill("solid", fgColor="D6E4F0")
_sum_fill = PatternFill("solid", fgColor="E2EFDA")
_sum_font = Font("Calibri", bold=True, size=11, color="375623")


def cell_val(cell):
    """Return cell value, skip formulas."""
    v = cell.value
    return None if isinstance(v, str) and v.startswith("=") else v


def load_data():
    """Load workbook and collect all assignees with their task counts."""
    if not SOURCE.exists():
        print(f"  ERROR: {SOURCE} not found"); sys.exit(1)

    print(f"  Loading {SOURCE.name} ...")
    wb = openpyxl.load_workbook(str(SOURCE), data_only=True)
    names = {}  # name -> count

    for sname, cfg in SHEETS.items():
        if sname not in wb.sheetnames: continue
        ws = wb[sname]
        for r in range(cfg["start"], ws.max_row + 1):
            v = cell_val(ws.cell(r, cfg["name"]))
            if v and isinstance(v, str):
                n = v.strip()
                if n and n != "-":
                    names[n] = names.get(n, 0) + 1

    return wb, names


def extract(wb, target):
    """Pull all task rows matching target name across all sheets."""
    tasks = []
    for sname, cfg in SHEETS.items():
        if sname not in wb.sheetnames: continue
        ws = wb[sname]
        for r in range(cfg["start"], ws.max_row + 1):
            v = cell_val(ws.cell(r, cfg["name"]))
            if not (v and isinstance(v, str) and v.strip().lower() == target.lower()):
                continue
            row = {"task_id": cell_val(ws.cell(r, cfg["task"])), "sheet": sname}
            for key, col in cfg["cols"].items():
                row[key] = cell_val(ws.cell(r, col)) if col else None
            tasks.append(row)
    return tasks


def save_report(name, tasks):
    """Create a formatted Excel report and save it."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Task Report"
    nc = len(HEADERS)

    # Title
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=nc)
    t = ws.cell(1, 1, f"Task Report - {name}")
    t.font = Font("Calibri", bold=True, size=14, color="2F5496")
    ws.row_dimensions[1].height = 30

    # Subtitle
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=nc)
    ws.cell(2, 1, f"Generated: {datetime.now():%d-%b-%Y %I:%M %p}  |  Tasks: {len(tasks)}").font = \
        Font("Calibri", italic=True, size=11, color="555555")

    # Status summary
    stats = {}
    for t_ in tasks:
        s = t_.get("status") or "Unknown"
        stats[s] = stats.get(s, 0) + 1

    ws.merge_cells(start_row=4, start_column=1, end_row=4, end_column=nc)
    ws.cell(4, 1, "Summary").font = _sum_font
    ws.cell(4, 1).fill = _sum_fill
    c = 1
    for s, cnt in sorted(stats.items(), key=lambda x: -x[1]):
        ws.cell(5, c, f"{s}:").font = Font("Calibri", bold=True, size=11)
        ws.cell(5, c+1, cnt)
        c += 2
        if c >= nc: break

    # Header row
    hr = 7
    for i, h in enumerate(HEADERS, 1):
        c = ws.cell(hr, i, h)
        c.font, c.fill, c.alignment, c.border = _hdr_font, _hdr_fill, Alignment("center","center"), _border

    # Data rows
    for idx, task in enumerate(tasks):
        r = hr + 1 + idx
        for ci, key in enumerate(FIELDS, 1):
            c = ws.cell(r, ci, task.get(key))
            c.font, c.border = Font("Calibri", size=11), _border
            c.alignment = Alignment("center","center") if key in ("task_id","status","milestone","billed_pct","sheet") \
                else Alignment("left","center", wrap_text=True)
        if idx % 2:
            for ci in range(1, nc+1): ws.cell(r, ci).fill = _alt_fill

    # Total row
    tr = hr + 1 + len(tasks)
    for ci in range(1, nc+1):
        ws.cell(tr, ci).fill = _sum_fill
        ws.cell(tr, ci).border = _border
    ws.cell(tr, 1, "TOTAL").font = _sum_font
    ws.cell(tr, 2, f"{len(tasks)} tasks").font = _sum_font
    pts_i = FIELDS.index("points") + 1
    ws.cell(tr, pts_i, round(sum(t.get("points") or 0 for t in tasks), 2)).font = _sum_font

    # Formatting
    for i, w in enumerate(COL_WIDTHS, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = f"A{hr+1}"
    ws.auto_filter.ref = f"A{hr}:{get_column_letter(nc)}{hr+len(tasks)}"

    safe = name.replace(" ", "_").replace("/", "-")
    fname = f"Tasks_{safe}_{datetime.now():%Y%m%d_%H%M%S}.xlsx"
    path = BASE_DIR / fname
    wb.save(str(path))
    return path


def match(query, names):
    """Case-insensitive partial name matching."""
    q = query.lower().strip()
    exact = [n for n in names if n.lower() == q]
    if exact: return exact
    return [n for n in names if q in n.lower()]


def main():
    print("\n  +-----------------------------------------------------+")
    print("  |       TASK ID EXTRACTOR - Billing Automation         |")
    print("  +-----------------------------------------------------+\n")

    wb, names = load_data()
    print(f"  {len(names)} assignees, {sum(names.values())} total tasks.\n")

    while True:
        sorted_n = sorted(names, key=str.lower)
        for i, n in enumerate(sorted_n, 1):
            print(f"  {i:3d}. {n:<40s} ({names[n]:3d} tasks)")

        try:
            inp = input("\n  Name or # (q to quit): ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if inp.lower() in ("q","quit","exit",""):
            break

        pick = None
        try:
            num = int(inp)
            if 1 <= num <= len(sorted_n): pick = sorted_n[num-1]
        except ValueError: pass

        if not pick:
            hits = match(inp, names)
            if not hits:
                print(f"  No match for '{inp}'.\n"); continue
            if len(hits) == 1:
                pick = hits[0]
            else:
                print(f"  Multiple matches:")
                for i, h in enumerate(hits, 1): print(f"    {i}. {h}")
                try:
                    c = int(input("  Pick #: "))
                    pick = hits[c-1] if 1 <= c <= len(hits) else None
                except: pass
                if not pick: print("  Invalid.\n"); continue

        tasks = extract(wb, pick)
        if not tasks:
            print(f"  No tasks for '{pick}'.\n"); continue

        path = save_report(pick, tasks)
        print(f"\n  Saved {len(tasks)} tasks -> {path.name}")
        print(f"  Path: {path}\n")

        try:
            if input("  Another? (y/n): ").strip().lower() not in ("y","yes"): break
        except: break
        print()

    print("\n  Done.\n")

if __name__ == "__main__":
    main()
